/* CoinHslConfig.h.  Generated from CoinHslConfig.h.in by configure.  */
/* config_coinhsl.h.in. */

#ifndef __CONFIG_COINHSL_H__
#define __CONFIG_COINHSL_H__

/* Define to 1 if MA27 is available. */
#define COINHSL_HAS_MA27 1

/* Define to 1 if MA28 is available. */
#define COINHSL_HAS_MA28 1

/* Define to 1 if MA57 is available. */
#define COINHSL_HAS_MA57 1

/* Define to 1 if HSL_MA77 is available. */
#define COINHSL_HAS_MA77 1

/* Define to 1 if HSL_MA86 is available. */
#define COINHSL_HAS_MA86 1

/* Define to 1 if HSL_MA97 is available. */
#define COINHSL_HAS_MA97 1

/* Define to 1 if MC19 is available. */
#define COINHSL_HAS_MC19 1

#endif
